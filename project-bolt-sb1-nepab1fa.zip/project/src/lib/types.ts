export interface Medicine {
  id: string;
  name: string;
  batch_number: string | null;
  price: number;
  stock_quantity: number;
  gst_percentage: number;
  created_at: string;
  updated_at: string;
}

export interface Bill {
  id: string;
  bill_number: string;
  customer_name: string | null;
  customer_phone: string | null;
  subtotal: number;
  gst_amount: number;
  total_amount: number;
  created_at: string;
}

export interface BillItem {
  id: string;
  bill_id: string;
  medicine_id: string | null;
  medicine_name: string;
  quantity: number;
  unit_price: number;
  gst_percentage: number;
  item_total: number;
}

export interface Database {
  public: {
    Tables: {
      medicines: {
        Row: Medicine;
        Insert: Omit<Medicine, 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Medicine, 'id' | 'created_at' | 'updated_at'>>;
      };
      bills: {
        Row: Bill;
        Insert: Omit<Bill, 'id' | 'created_at'>;
        Update: Partial<Omit<Bill, 'id' | 'created_at'>>;
      };
      bill_items: {
        Row: BillItem;
        Insert: Omit<BillItem, 'id'>;
        Update: Partial<Omit<BillItem, 'id'>>;
      };
    };
  };
}
