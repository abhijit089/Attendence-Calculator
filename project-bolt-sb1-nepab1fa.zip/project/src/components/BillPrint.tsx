import { useEffect, useState } from 'react';
import { Printer, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Bill, BillItem } from '../lib/types';

interface BillPrintProps {
  billId: string;
  onClose: () => void;
}

const SHOP_NAME = 'UMMA HEALTHCARE';
const OWNER_NAME = 'AMJADUL HAQUE';
const PHONE_NUMBER = '7679516622';

export default function BillPrint({ billId, onClose }: BillPrintProps) {
  const [bill, setBill] = useState<Bill | null>(null);
  const [billItems, setBillItems] = useState<BillItem[]>([]);

  useEffect(() => {
    fetchBillDetails();
  }, [billId]);

  async function fetchBillDetails() {
    const { data: billData, error: billError } = await supabase
      .from('bills')
      .select('*')
      .eq('id', billId)
      .single();

    if (!billError && billData) {
      setBill(billData);
    }

    const { data: itemsData, error: itemsError } = await supabase
      .from('bill_items')
      .select('*')
      .eq('bill_id', billId);

    if (!itemsError && itemsData) {
      setBillItems(itemsData);
    }
  }

  function handlePrint() {
    window.print();
  }

  if (!bill) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white p-8 rounded-lg">
          <p>Loading bill...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-screen overflow-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center print:hidden">
          <h2 className="text-xl font-semibold text-gray-800">Bill Preview</h2>
          <div className="flex gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition"
            >
              <Printer size={20} />
              Print
            </button>
            <button
              onClick={onClose}
              className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="p-8 print:p-6" id="bill-content">
          <div className="border-2 border-gray-800 p-6">
            <div className="text-center border-b-2 border-gray-800 pb-4 mb-4">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{SHOP_NAME}</h1>
              <p className="text-lg text-gray-700">Proprietor: {OWNER_NAME}</p>
              <p className="text-lg text-gray-700">Phone: {PHONE_NUMBER}</p>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
              <div>
                <p className="text-gray-600">Bill No:</p>
                <p className="font-semibold text-gray-900">{bill.bill_number}</p>
              </div>
              <div className="text-right">
                <p className="text-gray-600">Date:</p>
                <p className="font-semibold text-gray-900">
                  {new Date(bill.created_at).toLocaleString('en-IN', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
              </div>
              {bill.customer_name && (
                <>
                  <div>
                    <p className="text-gray-600">Customer Name:</p>
                    <p className="font-semibold text-gray-900">{bill.customer_name}</p>
                  </div>
                  {bill.customer_phone && (
                    <div>
                      <p className="text-gray-600">Customer Phone:</p>
                      <p className="font-semibold text-gray-900">{bill.customer_phone}</p>
                    </div>
                  )}
                </>
              )}
            </div>

            <table className="w-full mb-6 border-collapse">
              <thead>
                <tr className="border-y-2 border-gray-800">
                  <th className="text-left py-3 px-2 text-sm font-bold text-gray-900">S.No</th>
                  <th className="text-left py-3 px-2 text-sm font-bold text-gray-900">Medicine Name</th>
                  <th className="text-center py-3 px-2 text-sm font-bold text-gray-900">Qty</th>
                  <th className="text-right py-3 px-2 text-sm font-bold text-gray-900">Price</th>
                  <th className="text-right py-3 px-2 text-sm font-bold text-gray-900">GST %</th>
                  <th className="text-right py-3 px-2 text-sm font-bold text-gray-900">Amount</th>
                </tr>
              </thead>
              <tbody>
                {billItems.map((item, index) => (
                  <tr key={item.id} className="border-b border-gray-300">
                    <td className="py-2 px-2 text-sm text-gray-800">{index + 1}</td>
                    <td className="py-2 px-2 text-sm text-gray-800">{item.medicine_name}</td>
                    <td className="py-2 px-2 text-sm text-gray-800 text-center">{item.quantity}</td>
                    <td className="py-2 px-2 text-sm text-gray-800 text-right">
                      ₹{item.unit_price.toFixed(2)}
                    </td>
                    <td className="py-2 px-2 text-sm text-gray-800 text-right">
                      {item.gst_percentage}%
                    </td>
                    <td className="py-2 px-2 text-sm text-gray-800 text-right">
                      ₹{item.item_total.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="border-t-2 border-gray-800 pt-4 space-y-2">
              <div className="flex justify-between text-base">
                <span className="font-semibold text-gray-700">Subtotal:</span>
                <span className="font-semibold text-gray-900">₹{bill.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-base">
                <span className="font-semibold text-gray-700">GST Amount:</span>
                <span className="font-semibold text-gray-900">₹{bill.gst_amount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-xl font-bold border-t-2 border-gray-800 pt-2">
                <span className="text-gray-900">Total Amount:</span>
                <span className="text-gray-900">₹{bill.total_amount.toFixed(2)}</span>
              </div>
            </div>

            <div className="mt-4 pt-2 border-t border-gray-300">
              <div className="flex justify-between text-sm py-1">
                <span className="font-semibold text-gray-700">Payment Mode:</span>
                <span className="font-semibold text-gray-900">{bill.payment_mode || 'Cash'}</span>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-300 text-center">
              <p className="text-sm text-gray-600 italic">Thank you for your purchase!</p>
              <p className="text-sm text-gray-600 mt-2">For queries, please contact: {PHONE_NUMBER}</p>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #bill-content, #bill-content * {
            visibility: visible;
          }
          #bill-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          .print\\:hidden {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
}
