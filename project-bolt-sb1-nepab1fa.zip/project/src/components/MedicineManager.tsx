import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Search, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Medicine } from '../lib/types';

export default function MedicineManager() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [filteredMedicines, setFilteredMedicines] = useState<Medicine[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [stockEditId, setStockEditId] = useState<string | null>(null);
  const [stockChange, setStockChange] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    batch_number: '',
    price: '',
    stock_quantity: '',
    gst_percentage: '12',
    low_stock_threshold: '10',
  });

  useEffect(() => {
    fetchMedicines();
  }, []);

  useEffect(() => {
    const filtered = medicines.filter((medicine) =>
      medicine.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (medicine.batch_number?.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    setFilteredMedicines(filtered);
  }, [searchQuery, medicines]);

  async function fetchMedicines() {
    const { data, error } = await supabase
      .from('medicines')
      .select('*')
      .order('name');

    if (!error && data) {
      setMedicines(data);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const medicineData = {
      name: formData.name,
      batch_number: formData.batch_number || null,
      price: parseFloat(formData.price),
      stock_quantity: parseInt(formData.stock_quantity),
      gst_percentage: parseFloat(formData.gst_percentage),
      low_stock_threshold: parseInt(formData.low_stock_threshold),
    };

    if (editingMedicine) {
      const { error } = await supabase
        .from('medicines')
        .update(medicineData)
        .eq('id', editingMedicine.id);

      if (!error) {
        fetchMedicines();
        resetForm();
      }
    } else {
      const { error } = await supabase
        .from('medicines')
        .insert([medicineData]);

      if (!error) {
        fetchMedicines();
        resetForm();
      }
    }
  }

  async function handleDelete(id: string) {
    if (confirm('Are you sure you want to delete this medicine?')) {
      const { error } = await supabase
        .from('medicines')
        .delete()
        .eq('id', id);

      if (!error) {
        fetchMedicines();
      }
    }
  }

  function handleEdit(medicine: Medicine) {
    setEditingMedicine(medicine);
    setFormData({
      name: medicine.name,
      batch_number: medicine.batch_number || '',
      price: medicine.price.toString(),
      stock_quantity: medicine.stock_quantity.toString(),
      gst_percentage: medicine.gst_percentage.toString(),
      low_stock_threshold: (medicine.low_stock_threshold || 10).toString(),
    });
    setShowForm(true);
  }

  async function updateStock(medicineId: string, change: number) {
    const medicine = medicines.find((m) => m.id === medicineId);
    if (!medicine) return;

    const newStock = medicine.stock_quantity + change;
    if (newStock < 0) {
      alert('Stock cannot be negative');
      return;
    }

    const { error } = await supabase
      .from('medicines')
      .update({ stock_quantity: newStock })
      .eq('id', medicineId);

    if (!error) {
      fetchMedicines();
      setStockEditId(null);
      setStockChange('');
    }
  }

  function resetForm() {
    setFormData({
      name: '',
      batch_number: '',
      price: '',
      stock_quantity: '',
      gst_percentage: '12',
      low_stock_threshold: '10',
    });
    setEditingMedicine(null);
    setShowForm(false);
  }

  const lowStockMedicines = medicines.filter(
    (m) => m.stock_quantity <= (m.low_stock_threshold || 10)
  );

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      {lowStockMedicines.length > 0 && (
        <div className="mb-6 bg-red-50 border-l-4 border-red-600 p-4 rounded">
          <div className="flex items-start gap-3">
            <AlertTriangle className="text-red-600 flex-shrink-0 mt-0.5" size={20} />
            <div>
              <h3 className="font-semibold text-red-800 mb-2">Low Stock Alert</h3>
              <ul className="text-sm text-red-700 space-y-1">
                {lowStockMedicines.map((m) => (
                  <li key={m.id}>
                    {m.name} - Current: {m.stock_quantity} units (Threshold: {m.low_stock_threshold || 10})
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-800">Medicine Inventory</h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition"
        >
          <Plus size={20} />
          Add Medicine
        </button>
      </div>

      <div className="mb-6 relative">
        <Search className="absolute left-3 top-3 text-gray-400" size={20} />
        <input
          type="text"
          placeholder="Search medicines by name or batch number..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
        />
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Medicine Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Batch Number
              </label>
              <input
                type="text"
                value={formData.batch_number}
                onChange={(e) => setFormData({ ...formData, batch_number: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Price (₹) *
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Stock Quantity *
              </label>
              <input
                type="number"
                required
                value={formData.stock_quantity}
                onChange={(e) => setFormData({ ...formData, stock_quantity: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                GST (%) *
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={formData.gst_percentage}
                onChange={(e) => setFormData({ ...formData, gst_percentage: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Low Stock Threshold *
              </label>
              <input
                type="number"
                required
                value={formData.low_stock_threshold}
                onChange={(e) => setFormData({ ...formData, low_stock_threshold: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button
              type="submit"
              className="bg-teal-600 text-white px-6 py-2 rounded-lg hover:bg-teal-700 transition"
            >
              {editingMedicine ? 'Update' : 'Add'} Medicine
            </button>
            <button
              type="button"
              onClick={resetForm}
              className="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-400 transition"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Medicine Name</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Batch No.</th>
              <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Price (₹)</th>
              <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Stock</th>
              <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">GST (%)</th>
              <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredMedicines.map((medicine) => (
              <tr
                key={medicine.id}
                className={`border-b border-gray-100 hover:bg-gray-50 ${
                  medicine.stock_quantity <= (medicine.low_stock_threshold || 10)
                    ? 'bg-red-50'
                    : ''
                }`}
              >
                <td className="py-3 px-4 text-sm text-gray-800">{medicine.name}</td>
                <td className="py-3 px-4 text-sm text-gray-600">{medicine.batch_number || '-'}</td>
                <td className="py-3 px-4 text-sm text-gray-800 text-right">₹{medicine.price.toFixed(2)}</td>
                <td className="py-3 px-4">
                  {stockEditId === medicine.id ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        value={stockChange}
                        onChange={(e) => setStockChange(e.target.value)}
                        className="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                        placeholder="Change"
                      />
                      <button
                        onClick={() => updateStock(medicine.id, parseInt(stockChange) || 0)}
                        className="px-2 py-1 bg-teal-600 text-white text-xs rounded hover:bg-teal-700"
                      >
                        OK
                      </button>
                      <button
                        onClick={() => {
                          setStockEditId(null);
                          setStockChange('');
                        }}
                        className="px-2 py-1 bg-gray-300 text-gray-700 text-xs rounded hover:bg-gray-400"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <div
                      onClick={() => {
                        setStockEditId(medicine.id);
                        setStockChange('');
                      }}
                      className="text-sm text-gray-800 text-right cursor-pointer hover:text-teal-600"
                    >
                      {medicine.stock_quantity} units
                    </div>
                  )}
                </td>
                <td className="py-3 px-4 text-sm text-gray-800 text-right">{medicine.gst_percentage}%</td>
                <td className="py-3 px-4">
                  <div className="flex justify-center gap-2">
                    <button
                      onClick={() => handleEdit(medicine)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded transition"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button
                      onClick={() => handleDelete(medicine.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded transition"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredMedicines.length === 0 && medicines.length > 0 && (
          <div className="text-center py-8 text-gray-500">
            No medicines match your search.
          </div>
        )}
        {medicines.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No medicines in inventory. Add your first medicine to get started.
          </div>
        )}
      </div>
    </div>
  );
}
