import { useState, useEffect } from 'react';
import { Plus, Trash2, Receipt, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Medicine } from '../lib/types';

interface BillItem {
  medicine: Medicine;
  quantity: number;
}

interface BillingFormProps {
  onBillCreated: (billId: string) => void;
}

export default function BillingForm({ onBillCreated }: BillingFormProps) {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [filteredMedicines, setFilteredMedicines] = useState<Medicine[]>([]);
  const [billItems, setBillItems] = useState<BillItem[]>([]);
  const [selectedMedicineId, setSelectedMedicineId] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMode, setPaymentMode] = useState('Cash');
  const [searchQuery, setSearchQuery] = useState('');
  const [showMedicineDropdown, setShowMedicineDropdown] = useState(false);

  useEffect(() => {
    fetchMedicines();
  }, []);

  useEffect(() => {
    const filtered = medicines.filter((medicine) =>
      medicine.name.toLowerCase().includes(searchQuery.toLowerCase()) && medicine.stock_quantity > 0
    );
    setFilteredMedicines(filtered);
  }, [searchQuery, medicines]);

  async function fetchMedicines() {
    const { data, error } = await supabase
      .from('medicines')
      .select('*')
      .order('name');

    if (!error && data) {
      setMedicines(data);
    }
  }

  function selectMedicine(medicine: Medicine) {
    setSelectedMedicineId(medicine.id);
    setSearchQuery('');
    setShowMedicineDropdown(false);
  }

  function addItem() {
    if (!selectedMedicineId || !quantity) return;

    const medicine = medicines.find((m) => m.id === selectedMedicineId);
    if (!medicine) return;

    const qty = parseInt(quantity);
    if (qty <= 0 || qty > medicine.stock_quantity) {
      alert('Invalid quantity or insufficient stock');
      return;
    }

    const existingItemIndex = billItems.findIndex(
      (item) => item.medicine.id === selectedMedicineId
    );

    if (existingItemIndex >= 0) {
      const updatedItems = [...billItems];
      updatedItems[existingItemIndex].quantity += qty;
      setBillItems(updatedItems);
    } else {
      setBillItems([...billItems, { medicine, quantity: qty }]);
    }

    setSelectedMedicineId('');
    setQuantity('1');
  }

  function removeItem(index: number) {
    setBillItems(billItems.filter((_, i) => i !== index));
  }

  function calculateItemTotal(item: BillItem) {
    const subtotal = item.medicine.price * item.quantity;
    const gstAmount = (subtotal * item.medicine.gst_percentage) / 100;
    return subtotal + gstAmount;
  }

  function calculateTotals() {
    let subtotal = 0;
    let gstAmount = 0;

    billItems.forEach((item) => {
      const itemSubtotal = item.medicine.price * item.quantity;
      const itemGst = (itemSubtotal * item.medicine.gst_percentage) / 100;
      subtotal += itemSubtotal;
      gstAmount += itemGst;
    });

    return {
      subtotal,
      gstAmount,
      total: subtotal + gstAmount,
    };
  }

  async function createBill() {
    if (billItems.length === 0) {
      alert('Please add at least one item to the bill');
      return;
    }

    const totals = calculateTotals();
    const billNumber = `BILL-${Date.now()}`;

    const { data: billData, error: billError } = await supabase
      .from('bills')
      .insert([
        {
          bill_number: billNumber,
          customer_name: customerName || null,
          customer_phone: customerPhone || null,
          subtotal: totals.subtotal,
          gst_amount: totals.gstAmount,
          total_amount: totals.total,
          payment_mode: paymentMode,
        },
      ])
      .select()
      .single();

    if (billError || !billData) {
      alert('Error creating bill');
      return;
    }

    const billItemsData = billItems.map((item) => ({
      bill_id: billData.id,
      medicine_id: item.medicine.id,
      medicine_name: item.medicine.name,
      quantity: item.quantity,
      unit_price: item.medicine.price,
      gst_percentage: item.medicine.gst_percentage,
      item_total: calculateItemTotal(item),
    }));

    const { error: itemsError } = await supabase
      .from('bill_items')
      .insert(billItemsData);

    if (itemsError) {
      alert('Error creating bill items');
      return;
    }

    for (const item of billItems) {
      await supabase
        .from('medicines')
        .update({ stock_quantity: item.medicine.stock_quantity - item.quantity })
        .eq('id', item.medicine.id);
    }

    setBillItems([]);
    setCustomerName('');
    setCustomerPhone('');
    setPaymentMode('Cash');
    setSearchQuery('');
    onBillCreated(billData.id);
  }

  const totals = calculateTotals();

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Create Bill</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Customer Name
          </label>
          <input
            type="text"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            placeholder="Optional"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Customer Phone
          </label>
          <input
            type="tel"
            value={customerPhone}
            onChange={(e) => setCustomerPhone(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            placeholder="Optional"
          />
        </div>
      </div>

      <div className="border-t pt-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Payment Mode
            </label>
            <select
              value={paymentMode}
              onChange={(e) => setPaymentMode(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            >
              <option value="Cash">Cash</option>
              <option value="Card">Card</option>
              <option value="UPI">UPI</option>
              <option value="Check">Check</option>
              <option value="Online">Online</option>
            </select>
          </div>
        </div>

        <h3 className="text-sm font-semibold text-gray-700 mb-3">Add Items</h3>
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <div className="relative">
              <Search className="absolute left-3 top-3 text-gray-400 pointer-events-none" size={18} />
              <input
                type="text"
                placeholder="Search medicine..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowMedicineDropdown(true);
                }}
                onFocus={() => setShowMedicineDropdown(true)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>
            {showMedicineDropdown && filteredMedicines.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-10 max-h-48 overflow-y-auto">
                {filteredMedicines.map((medicine) => (
                  <div
                    key={medicine.id}
                    onClick={() => selectMedicine(medicine)}
                    className="px-3 py-2 hover:bg-teal-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                  >
                    <div className="font-medium text-gray-800">{medicine.name}</div>
                    <div className="text-sm text-gray-600">
                      ₹{medicine.price.toFixed(2)} | Stock: {medicine.stock_quantity}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          {selectedMedicineId && (
            <>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                placeholder="Qty"
              />
              <button
                onClick={addItem}
                className="flex items-center gap-2 bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition"
              >
                <Plus size={20} />
                Add
              </button>
            </>
          )}
        </div>
      </div>

      {billItems.length > 0 && (
        <div className="mb-6">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-2 px-2 text-sm font-semibold text-gray-700">Medicine</th>
                <th className="text-center py-2 px-2 text-sm font-semibold text-gray-700">Qty</th>
                <th className="text-right py-2 px-2 text-sm font-semibold text-gray-700">Price</th>
                <th className="text-right py-2 px-2 text-sm font-semibold text-gray-700">GST %</th>
                <th className="text-right py-2 px-2 text-sm font-semibold text-gray-700">Total</th>
                <th className="text-center py-2 px-2 text-sm font-semibold text-gray-700"></th>
              </tr>
            </thead>
            <tbody>
              {billItems.map((item, index) => (
                <tr key={index} className="border-b border-gray-100">
                  <td className="py-2 px-2 text-sm text-gray-800">{item.medicine.name}</td>
                  <td className="py-2 px-2 text-sm text-gray-800 text-center">{item.quantity}</td>
                  <td className="py-2 px-2 text-sm text-gray-800 text-right">
                    ₹{item.medicine.price.toFixed(2)}
                  </td>
                  <td className="py-2 px-2 text-sm text-gray-800 text-right">
                    {item.medicine.gst_percentage}%
                  </td>
                  <td className="py-2 px-2 text-sm text-gray-800 text-right">
                    ₹{calculateItemTotal(item).toFixed(2)}
                  </td>
                  <td className="py-2 px-2 text-center">
                    <button
                      onClick={() => removeItem(index)}
                      className="p-1 text-red-600 hover:bg-red-50 rounded transition"
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="mt-4 space-y-2 border-t pt-4">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Subtotal:</span>
              <span className="font-medium text-gray-800">₹{totals.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">GST:</span>
              <span className="font-medium text-gray-800">₹{totals.gstAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-lg font-semibold border-t pt-2">
              <span className="text-gray-800">Total:</span>
              <span className="text-teal-600">₹{totals.total.toFixed(2)}</span>
            </div>
          </div>

          <button
            onClick={createBill}
            className="w-full mt-6 flex items-center justify-center gap-2 bg-teal-600 text-white px-6 py-3 rounded-lg hover:bg-teal-700 transition font-medium"
          >
            <Receipt size={20} />
            Generate Bill
          </button>
        </div>
      )}
    </div>
  );
}
