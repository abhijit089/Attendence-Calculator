import { useEffect, useState } from 'react';
import { TrendingUp, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Bill } from '../lib/types';

export default function SalesAnalytics() {
  const [bills, setBills] = useState<Bill[]>([]);
  const [todaySales, setTodaySales] = useState(0);
  const [todayCount, setTodayCount] = useState(0);
  const [monthlySales, setMonthlySales] = useState(0);
  const [monthlyCount, setMonthlyCount] = useState(0);

  useEffect(() => {
    fetchSalesData();
  }, []);

  async function fetchSalesData() {
    const { data, error } = await supabase
      .from('bills')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setBills(data);
      calculateSales(data);
    }
  }

  function calculateSales(billsData: Bill[]) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();

    let todayTotal = 0;
    let todayBillCount = 0;
    let monthlyTotal = 0;
    let monthlyBillCount = 0;

    billsData.forEach((bill) => {
      const billDate = new Date(bill.created_at);
      billDate.setHours(0, 0, 0, 0);

      if (billDate.getTime() === today.getTime()) {
        todayTotal += bill.total_amount;
        todayBillCount++;
      }

      if (
        billDate.getMonth() === currentMonth &&
        billDate.getFullYear() === currentYear
      ) {
        monthlyTotal += bill.total_amount;
        monthlyBillCount++;
      }
    });

    setTodaySales(todayTotal);
    setTodayCount(todayBillCount);
    setMonthlySales(monthlyTotal);
    setMonthlyCount(monthlyBillCount);
  }

  const avgBillToday = todayCount > 0 ? todaySales / todayCount : 0;
  const avgBillMonth = monthlyCount > 0 ? monthlySales / monthlyCount : 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-sm font-medium text-gray-600 mb-1">Today's Sales</h3>
            <p className="text-3xl font-bold text-teal-600">₹{todaySales.toFixed(2)}</p>
            <p className="text-sm text-gray-500 mt-2">{todayCount} bills generated</p>
            <p className="text-sm text-gray-500">Avg: ₹{avgBillToday.toFixed(2)}</p>
          </div>
          <div className="bg-teal-50 p-3 rounded-lg">
            <Calendar className="text-teal-600" size={24} />
          </div>
        </div>
        <div className="border-t pt-4">
          <div className="space-y-2">
            {bills
              .filter((bill) => {
                const billDate = new Date(bill.created_at);
                const today = new Date();
                return (
                  billDate.getDate() === today.getDate() &&
                  billDate.getMonth() === today.getMonth() &&
                  billDate.getFullYear() === today.getFullYear()
                );
              })
              .slice(0, 5)
              .map((bill) => (
                <div
                  key={bill.id}
                  className="flex justify-between text-sm py-1 border-b border-gray-100 last:border-b-0"
                >
                  <span className="text-gray-600">{bill.bill_number}</span>
                  <span className="font-medium text-gray-800">₹{bill.total_amount.toFixed(2)}</span>
                </div>
              ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-sm font-medium text-gray-600 mb-1">Monthly Sales</h3>
            <p className="text-3xl font-bold text-blue-600">₹{monthlySales.toFixed(2)}</p>
            <p className="text-sm text-gray-500 mt-2">{monthlyCount} bills generated</p>
            <p className="text-sm text-gray-500">Avg: ₹{avgBillMonth.toFixed(2)}</p>
          </div>
          <div className="bg-blue-50 p-3 rounded-lg">
            <TrendingUp className="text-blue-600" size={24} />
          </div>
        </div>
        <div className="border-t pt-4">
          <div className="space-y-2">
            {bills
              .filter((bill) => {
                const billDate = new Date(bill.created_at);
                const today = new Date();
                return (
                  billDate.getMonth() === today.getMonth() &&
                  billDate.getFullYear() === today.getFullYear()
                );
              })
              .slice(0, 5)
              .map((bill) => (
                <div
                  key={bill.id}
                  className="flex justify-between text-sm py-1 border-b border-gray-100 last:border-b-0"
                >
                  <span className="text-gray-600">
                    {new Date(bill.created_at).toLocaleDateString('en-IN')} - {bill.bill_number}
                  </span>
                  <span className="font-medium text-gray-800">₹{bill.total_amount.toFixed(2)}</span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
