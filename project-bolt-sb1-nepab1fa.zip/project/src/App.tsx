import { useState } from 'react';
import { Pill } from 'lucide-react';
import MedicineManager from './components/MedicineManager';
import BillingForm from './components/BillingForm';
import BillPrint from './components/BillPrint';
import SalesAnalytics from './components/SalesAnalytics';

function App() {
  const [activeTab, setActiveTab] = useState<'inventory' | 'billing' | 'analytics'>('billing');
  const [currentBillId, setCurrentBillId] = useState<string | null>(null);

  function handleBillCreated(billId: string) {
    setCurrentBillId(billId);
  }

  function handleCloseBill() {
    setCurrentBillId(null);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-3">
            <Pill className="text-teal-600" size={32} />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">UMMA HEALTHCARE</h1>
              <p className="text-sm text-gray-600">Medicine Billing System</p>
            </div>
          </div>
        </div>
      </header>

      <nav className="bg-white shadow-sm border-t">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-8">
            <button
              onClick={() => setActiveTab('billing')}
              className={`py-4 px-2 border-b-2 font-medium text-sm transition ${
                activeTab === 'billing'
                  ? 'border-teal-600 text-teal-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Billing
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className={`py-4 px-2 border-b-2 font-medium text-sm transition ${
                activeTab === 'inventory'
                  ? 'border-teal-600 text-teal-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Medicine Inventory
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`py-4 px-2 border-b-2 font-medium text-sm transition ${
                activeTab === 'analytics'
                  ? 'border-teal-600 text-teal-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Sales Analytics
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'inventory' ? (
          <MedicineManager />
        ) : activeTab === 'analytics' ? (
          <SalesAnalytics />
        ) : (
          <BillingForm onBillCreated={handleBillCreated} />
        )}
      </main>

      {currentBillId && (
        <BillPrint billId={currentBillId} onClose={handleCloseBill} />
      )}
    </div>
  );
}

export default App;
