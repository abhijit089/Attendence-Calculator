/*
  # Add Payment Mode and Low Stock Threshold

  1. Modifications
    - Add `payment_mode` column to bills table (Cash/Card/UPI/Check)
    - Add `low_stock_threshold` column to medicines table (alert when stock goes below this)
    - Add `gst_number` and `address` columns to track business details

  2. Security
    - RLS policies already in place, no changes needed
*/

ALTER TABLE bills 
ADD COLUMN IF NOT EXISTS payment_mode text DEFAULT 'Cash' CHECK (payment_mode IN ('Cash', 'Card', 'UPI', 'Check', 'Online'));

ALTER TABLE medicines
ADD COLUMN IF NOT EXISTS low_stock_threshold integer DEFAULT 10 CHECK (low_stock_threshold >= 0);