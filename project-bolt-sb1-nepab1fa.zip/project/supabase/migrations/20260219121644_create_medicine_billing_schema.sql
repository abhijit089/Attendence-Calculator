/*
  # Medicine Billing System Schema

  ## New Tables
  
  ### medicines
  - `id` (uuid, primary key) - Unique identifier for each medicine
  - `name` (text) - Medicine name
  - `batch_number` (text) - Batch number
  - `price` (decimal) - Price per unit
  - `stock_quantity` (integer) - Available stock
  - `gst_percentage` (decimal) - GST percentage (default 12%)
  - `created_at` (timestamp) - Record creation time
  - `updated_at` (timestamp) - Last update time

  ### bills
  - `id` (uuid, primary key) - Unique bill identifier
  - `bill_number` (text, unique) - Human-readable bill number
  - `customer_name` (text) - Customer name (optional)
  - `customer_phone` (text) - Customer phone (optional)
  - `subtotal` (decimal) - Amount before GST
  - `gst_amount` (decimal) - Total GST amount
  - `total_amount` (decimal) - Final amount including GST
  - `created_at` (timestamp) - Bill creation time

  ### bill_items
  - `id` (uuid, primary key) - Unique identifier
  - `bill_id` (uuid, foreign key) - Reference to bills table
  - `medicine_id` (uuid, foreign key) - Reference to medicines table
  - `medicine_name` (text) - Medicine name (stored for record)
  - `quantity` (integer) - Quantity purchased
  - `unit_price` (decimal) - Price per unit at time of purchase
  - `gst_percentage` (decimal) - GST percentage at time of purchase
  - `item_total` (decimal) - Total for this item including GST

  ## Security
  - Enable RLS on all tables
  - Public access for reading (for billing kiosk usage)
  - Public access for inserting (for creating bills)
*/

-- Create medicines table
CREATE TABLE IF NOT EXISTS medicines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  batch_number text,
  price decimal(10,2) NOT NULL CHECK (price >= 0),
  stock_quantity integer NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  gst_percentage decimal(5,2) NOT NULL DEFAULT 12.00 CHECK (gst_percentage >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create bills table
CREATE TABLE IF NOT EXISTS bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text UNIQUE NOT NULL,
  customer_name text,
  customer_phone text,
  subtotal decimal(10,2) NOT NULL CHECK (subtotal >= 0),
  gst_amount decimal(10,2) NOT NULL CHECK (gst_amount >= 0),
  total_amount decimal(10,2) NOT NULL CHECK (total_amount >= 0),
  created_at timestamptz DEFAULT now()
);

-- Create bill_items table
CREATE TABLE IF NOT EXISTS bill_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id uuid NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  medicine_id uuid REFERENCES medicines(id),
  medicine_name text NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  unit_price decimal(10,2) NOT NULL CHECK (unit_price >= 0),
  gst_percentage decimal(5,2) NOT NULL CHECK (gst_percentage >= 0),
  item_total decimal(10,2) NOT NULL CHECK (item_total >= 0)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_bill_items_bill_id ON bill_items(bill_id);
CREATE INDEX IF NOT EXISTS idx_bills_created_at ON bills(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_medicines_name ON medicines(name);

-- Enable Row Level Security
ALTER TABLE medicines ENABLE ROW LEVEL SECURITY;
ALTER TABLE bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE bill_items ENABLE ROW LEVEL SECURITY;

-- RLS Policies for medicines (allow public read and write for kiosk usage)
CREATE POLICY "Allow public read access to medicines"
  ON medicines FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public insert medicines"
  ON medicines FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public update medicines"
  ON medicines FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public delete medicines"
  ON medicines FOR DELETE
  TO anon
  USING (true);

-- RLS Policies for bills (allow public read and write)
CREATE POLICY "Allow public read access to bills"
  ON bills FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public insert bills"
  ON bills FOR INSERT
  TO anon
  WITH CHECK (true);

-- RLS Policies for bill_items (allow public read and write)
CREATE POLICY "Allow public read access to bill_items"
  ON bill_items FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public insert bill_items"
  ON bill_items FOR INSERT
  TO anon
  WITH CHECK (true);