function calculateAttendance() {
  const held = parseInt(document.getElementById("held").value);
  const attended = parseInt(document.getElementById("attended").value);
  const target = parseFloat(document.getElementById("target").value);

  const resultDiv = document.getElementById("result");
  resultDiv.innerHTML = "";

  if (isNaN(held) || isNaN(attended) || isNaN(target) || held === 0) {
    resultDiv.innerHTML = "❗ Please enter valid numbers.";
    return;
  }

  const currentPercentage = (attended / held) * 100;
  const formattedCurrent = currentPercentage.toFixed(2);

  let message = `📊 Current Attendance: <strong>${formattedCurrent}%</strong><br><br>`;

  if (currentPercentage < target) {
    let x = 0;
    while (((attended + x) / (held + x)) * 100 < target) {
      x++;
    }
    message += `🔺 You need to attend <strong>${x}</strong> more class(es) consecutively to reach <strong>${target}%</strong>.`;
  } else {
    let y = 0;
    while (((attended) / (held + y)) * 100 >= target) {
      y++;
    }
    y--;
    message += `🟢 You can miss <strong>${y}</strong> more class(es) and still stay above <strong>${target}%</strong>.`;
  }

  resultDiv.innerHTML = message;
}

function calculateWeeklyHeld() {
  const days = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
  let total = 0;

  for (let day of days) {
    const value = parseInt(document.getElementById(day).value) || 0;
    total += value;
  }

  document.getElementById("weeklyTotalResult").innerText =
    `📅 Weekly Total: ${total} classes`;

  return total;
}

function autoUpdateHeldFromTimetable() {
  const todayIndex = new Date().getDay(); // 0 (Sun) to 6 (Sat)
  const daysMap = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const todayKey = daysMap[todayIndex];
  const todayDate = new Date().toDateString();

  const lastUpdated = localStorage.getItem("lastUpdatedDate");

  if (lastUpdated === todayDate) return;

  const todayClasses = parseInt(document.getElementById(todayKey)?.value || "0");
  const heldInput = document.getElementById("held");
  const currentHeld = parseInt(heldInput.value) || 0;

  if (!isNaN(todayClasses)) {
    heldInput.value = currentHeld + todayClasses;
    localStorage.setItem("lastUpdatedDate", todayDate);
  }
}

function calculateAfterLeave() {
  const held = parseInt(document.getElementById("held").value);
  const attended = parseInt(document.getElementById("attended").value);
  const leaves = parseInt(document.getElementById("leaves").value);
  const target = parseFloat(document.getElementById("target").value);

  const resultDiv = document.getElementById("leaveResult");
  resultDiv.innerHTML = "";

  if (
    isNaN(held) || isNaN(attended) ||
    isNaN(leaves) || isNaN(target) || held === 0
  ) {
    resultDiv.innerHTML = "❗ Please enter all required values.";
    return;
  }

  const newHeld = held + leaves;
  const newPercentage = (attended / newHeld) * 100;
  const formatted = newPercentage.toFixed(2);

  let status = newPercentage >= target
    ? `✅ You will still be above your target.`
    : `⚠️ You will fall below your target.`;

  resultDiv.innerHTML =
    `📊 After taking <strong>${leaves}</strong> leave(s), your attendance will be <strong>${formatted}%</strong>.<br>${status}`;
}
